# Tie-Tac-Toe-Using-Python
#We will design it in such a way that computer will never lose the game

# We are going to use Minimax Algo in this program
# Minimax can be defined as decision making concept which try to maximise your wins .

#We have to determine which is the best move to make using utility function.

#Utility function is basically a measurement of how valuable the final result is in the tree.
